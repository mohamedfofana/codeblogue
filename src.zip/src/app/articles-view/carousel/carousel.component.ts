import { Component, OnInit, Input, OnDestroy } from '@angular/core';

import { IArticle } from '../../services/models/article';
import { CommentService } from '../../services/comment.service';
import { ReplyService } from '../../services/reply.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html'
})
export class CarouselComponent implements OnInit, OnDestroy {
  
  @Input() article: IArticle;
  nbComments : number = 0;
  errorMessage: string;
  subs: [Subscription];

  constructor(private _commentService: CommentService,
    private _replyService: ReplyService) { }

  ngOnInit() {
    this.subs.push(this._commentService.getCommentsByArticle(this.article.titre).subscribe(data => this.nbComments += data.length, error => this.errorMessage = <any>error));    
    this.subs.push(this._replyService.getRepliesByArticle(this.article.titre).subscribe(data => this.nbComments += data.length, error => this.errorMessage = <any>error));  
  }

  ngOnDestroy(){
    this.subs.forEach(s => s.unsubscribe());
  }
}
