import { CommentService } from "app/services/comment.service";
import { ReplyService } from 'app/services/reply.service';
import { OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

export abstract class AbstractCommentHandler implements OnDestroy {
    // nbComments : number = 0;
    // errorMessage: string;
    subs: [Subscription];
    //constructor(private _commentService: CommentService, private _replyService: ReplyService) { }

    // setComments(titre:String){
    //         this._commentService.getCommentsByArticle(titre).subscribe(data => this.nbComments += data.length, error => this.errorMessage = <any>error);    
    //         this._replyService.getRepliesByArticle(titre).subscribe(data => this.nbComments += data.length, error => this.errorMessage = <any>error);  
    // }
    ngOnDestroy(){
        console.log('destroying');
        this.subs.forEach(s => s.unsubscribe());
    }

}