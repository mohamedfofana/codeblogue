export interface IComment {
     _id: number; 
    article_titre: String; 
    contenu: String;
    auteur: String;
    likes: number; 
    creation :Date; 
}
