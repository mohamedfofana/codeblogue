export interface IContact{
    nom: String; 
    email: String;  
    objet: String; 
    message: String; 
}