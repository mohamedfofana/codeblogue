export interface IReply {
     _id: number; 
    article_titre: String; 
    contenu: String;
    auteur: String;
    likes: number; 
    creation :Date; 
    comment_auteur: String;
    comment_creation: Date;
}
